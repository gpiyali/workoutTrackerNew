import { Injectable } from '@angular/core';
import { Http, Headers, Response } from "@angular/http";
import 'rxjs/Rx';
import { Observable } from "rxjs";


@Injectable()
export class SharedService {
  constructor(private _http:Http) { }
  AddWorkout(item:any):Observable<string>
  {
    return this._http.post("http://localhost:3001/workoutActive",item)
    .map((response:Response)=><string>response.json())
   
  }

  EditWorkout(item:any):Observable<string>
  {
    return this._http.put("http://localhost:3001/workouts/:workoutId",item)
    .map((response:Response)=><string>response.json())
   
  }
  DeleteWorkout(item:any):Observable<string>
  {
    return this._http.delete("http://localhost:3001/workouts/:workoutId",item)
    .map((response:Response)=><string>response.json())
   
  }
  GetWorkout()
  {
    return this._http.get("http://localhost:3001/workoutActive")
    .map((response:Response)=><string>response.json())
   
  }
  GetCategory()
  {
    return this._http.get("http://localhost:3001/category")
    .map((response:Response)=><string>response.json())
   
  }
  EditCategory(item:any):Observable<string>
  {
    return this._http.put("http://localhost:3001/category/:categoryId",item)
    .map((response:Response)=><string>response.json())
   
  }
  DeleteCategory(item:any):Observable<string>
  {
    return this._http.delete("http://localhost:3001/category/:categoryId",item)
    .map((response:Response)=><string>response.json())
   
  }
}

